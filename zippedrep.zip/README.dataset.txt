# RevaHackathon > 2023-07-03 2:02pm
https://universe.roboflow.com/academy-myeb7/revahackathon

Provided by a Roboflow user
License: MIT

